import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { PunchAttendancePage } from './punch-attendance.page';

describe('PunchAttendancePage', () => {
  let component: PunchAttendancePage;
  let fixture: ComponentFixture<PunchAttendancePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PunchAttendancePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(PunchAttendancePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
