import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PunchAttendancePageRoutingModule } from './punch-attendance-routing.module';

import { PunchAttendancePage } from './punch-attendance.page';
import { SharedModule } from 'src/app/shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule,
    SharedModule,
    PunchAttendancePageRoutingModule
  ],
  declarations: [PunchAttendancePage]
})
export class PunchAttendancePageModule {}
