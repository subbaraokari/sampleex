import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AttendancePage } from './attendance.page';

const routes: Routes = [
  {
    path: 'tabs',
    component: AttendancePage,
    children: [
      {
        path: 'punch',
        children: [
          {
            path: '',
            loadChildren: () => import('./punch-attendance/punch-attendance.module').then(m => m.PunchAttendancePageModule)
          }
        ]
      },
      {
        path: 'view',
        children: [
          {
            path: '',
            loadChildren: () => import('./attendance-details/attendance-details.module').then(m => m.AttendanceDetailsPageModule)
          }
        ]
      },
      {
        path: '',
        redirectTo: '/attendance/tabs/punch',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '',
    redirectTo: '/attendance/tabs/punch',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AttendancePageRoutingModule { }
