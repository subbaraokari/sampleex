import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attendance-details',
  templateUrl: './attendance-details.page.html',
  styleUrls: ['./attendance-details.page.scss'],
})
export class AttendanceDetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
