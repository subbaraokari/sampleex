import { CanLoad, UrlSegment, Router } from '@angular/router';
import { Route } from '@angular/compiler/src/core';
import { Observable } from 'rxjs';
import { take, tap } from 'rxjs/operators'
import { AuthService } from './auth.service';
import { Injectable } from '@angular/core';
@Injectable({
    providedIn: "root"
})
export class AuthGuard implements CanLoad {
    constructor(private authService: AuthService, private router: Router) {

    }
    canLoad(route: Route, segments: UrlSegment[]): Observable<boolean> | Promise<boolean> | boolean {
        return this.authService.userIsAuthenticated.pipe(take(1), tap(isAuthenticated => {
            if (!isAuthenticated) {
                this.router.navigateByUrl('/auth');
            }
        })
        );
    }
}