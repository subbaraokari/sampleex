export const environment = {
  production: true,
  googleMapsAPIKey: 'pk.eyJ1Ijoia3MtcmFvIiwiYSI6ImNrOGg1YWVydDAwcmgzZG9waDZoZXI0eGoifQ.DaiN5jqtQL-doEls3FT3nA',
  firebaseAPIKey: 'AIzaSyCqAH5VZfvmpsfKs0iUP9HJKvVsaTHZduk'
};
