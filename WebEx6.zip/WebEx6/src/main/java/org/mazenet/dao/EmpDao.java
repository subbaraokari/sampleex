package org.mazenet.dao;

import java.util.List;

import org.mazenet.model.Emp;

public interface EmpDao {
	List<Emp> getEmployees();
	Emp getEmployee(int eno);
	boolean delete(int eno);
}
