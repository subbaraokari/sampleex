package org.mazenet.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.mazenet.model.Emp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
@Repository
public class EmpDaoImpl implements EmpDao {
	@Autowired
	JdbcTemplate template;
	@Override
	public List<Emp> getEmployees() {
		String sql="select eno,name,address from emp";
		MyRowMapper mapper=new MyRowMapper();
		List<Emp> emps=template.query(sql, mapper);
		return emps;
	}
	@Override
	public Emp getEmployee(int eno) {
		String sql="select * from emp where eno=?";
		MyRowMapper rowMapper=new MyRowMapper();
		List<Emp> emps=template.query(sql, rowMapper,eno);
		return emps.get(0);
	}
	@Override
	public boolean delete(int eno) {
		boolean b=false;
		String sql="delete from emp where eno=?";
		int i=template.update(sql, eno);
		if(i>0)
			b=true;
		return b;
	}
}
class MyRowMapper implements RowMapper<Emp>{	
	@Override
	public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
		Emp e=new Emp();
		e.setEno(rs.getInt(1));
		e.setName(rs.getString(2));
		e.setAddress(rs.getString(3));
		return e;
	}
	
}
