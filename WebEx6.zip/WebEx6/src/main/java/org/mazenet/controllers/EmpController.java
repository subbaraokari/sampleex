package org.mazenet.controllers;

import java.lang.ProcessBuilder.Redirect;
import java.util.List;

import org.mazenet.model.Emp;
import org.mazenet.service.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class EmpController {
	@Autowired
	EmpService service;

	@GetMapping("/")
	public String showHome(Model model) {
		List<Emp> emps = service.getEmployees();
		model.addAttribute("employees", emps);
		return "index";
	}
	@GetMapping("/edit")
	public String showEdit(@RequestParam("eno") int eno,Model model) {
		Emp e=service.getEmp(eno);
		model.addAttribute(e);
		return "emp-form";
	}
	/*@PostMapping("/update")
	public String update(@ModelAttribute("emp") Emp emp) {
		
	}*/
	@GetMapping("/delete/{eno}")
	public String delete(@PathVariable("eno") int eno) {
		boolean b=service.delete(eno);
		return "redirect:/";
	}
	
}
