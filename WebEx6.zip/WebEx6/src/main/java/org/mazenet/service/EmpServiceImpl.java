package org.mazenet.service;

import java.util.List;

import org.mazenet.dao.EmpDao;
import org.mazenet.model.Emp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class EmpServiceImpl implements EmpService {
	@Autowired
	EmpDao dao;
	@Override
	public List<Emp> getEmployees() {
		
		return dao.getEmployees();
	}
	@Override
	public Emp getEmp(int eno) {
		// TODO Auto-generated method stub
		return dao.getEmployee(eno);
	}
	@Override
	public boolean delete(int eno) {
		return dao.delete(eno);
	}

}
