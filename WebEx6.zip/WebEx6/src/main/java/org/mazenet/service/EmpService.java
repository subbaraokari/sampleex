package org.mazenet.service;

import java.util.List;

import org.mazenet.model.Emp;

public interface EmpService {
	List<Emp> getEmployees();
	Emp getEmp(int eno);
	boolean delete(int eno);
}
